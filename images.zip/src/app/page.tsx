"use client"

import Rotas from "@/routers/rotes";

export default function Home() {

return(

<Rotas/>
);

}
"use client";
import Menudash from "@/components/menudash";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { getDatabase, ref, onValue } from "firebase/database";
import app from "@/services/firebase";
import Thirdbutton from "@/components/buttons/thirdbutton";

export default function Dashboard() {
    const [temperature, setTemperature] = useState("--");
    const [humidade, setHumidade] = useState("--");
    const [fanStatus, setFanStatus] = useState(null);
    const [lampStatus, setLampStatus] = useState(null);
    
    useEffect(() => {
        const db = getDatabase(app);
        const tempRef = ref(db, "sensores/temperatura");
        onValue(tempRef, (snapshot) => {
            const data = snapshot.val();
            setTemperature(data !== null ? data + "°C" : "--");
        });
    }, []);

    useEffect(() => {
        const db = getDatabase(app);
        const tempRef = ref(db, "sensores/umidade");
        onValue(tempRef, (snapshot) => {
            const data = snapshot.val();
            setHumidade(data !== null ? data + "%" : "--");
        });
    }, []);
    
    useEffect(() => {
        const db = getDatabase();
        const fanRef = ref(db, 'fan');
        onValue(fanRef, (snapshot) => {
          const fanValue = snapshot.val();
          setFanStatus(fanValue);
        });
        
        const lampRef = ref(db, 'lampada');
        onValue(lampRef, (snapshot) => {
          const lampValue = snapshot.val();
          setLampStatus(lampValue);
        });
    }, []);

    return (
        <div className="w-full min-h-screen bg-[#FFF7E3] flex flex-col">
            {/* Header */}
            <div>
                <Menudash />
            </div>

            {/* Dashboard Layout */}
            <div className="bg-[#F5E7C6] w-full lg:w-350 lg:mt-10 lg:ml-65 p-4">
                {/* Main Content - Single column on mobile, grid on lg+ */}
                <div className="flex flex-col lg:grid lg:grid-cols-4 gap-4 lg:gap-10">
                    {/* Temperature */}
                    <div className="bg-[#FF0000] w-full h-30 text-white p-6 shadow-lg rounded-lg text-center">
                        <h2 className="text-xl font-semibold">TEMPERATURA</h2>
                        <p className="mt-2 text-3xl font-bold">{temperature}</p>
                    </div>
                    
                    {/* Humidity */}
                    <div className="bg-[#2554FC] w-full h-30 text-white p-6 shadow-lg rounded-lg text-center">
                        <h2 className="text-xl font-semibold">UMIDADE</h2>
                        <p className="mt-2 text-3xl font-bold">{humidade}</p>
                    </div>
                    
                    {/* Lamp */}
                    <div className="bg-[#7F8088] w-full h-30 text-white p-6 shadow-lg rounded-lg text-center">
                        <h2 className="text-xl font-semibold">LÂMPADA</h2>
                        <p className="mt-2 text-3xl font-bold">
                            {lampStatus === true ? 'Ligada' : 'Desligada'}
                        </p>
                    </div>
                    
                    {/* Ventilation */}
                    <div className="bg-[#5CAFF0] w-full h-30 text-white p-6 shadow-lg rounded-lg text-center">
                        <h2 className="text-xl font-semibold">VENTILAÇÃO</h2>
                        <p className="mt-2 text-3xl font-bold">
                            {fanStatus === true ? 'Ligada' : 'Desligada'}
                        </p>
                    </div>

                    {/* Bird Age - moves position on lg+ */}
                    <div className="bg-[#FF9349] w-full h-30 text-white p-6 shadow-lg rounded-lg text-center lg:col-start-3">
                        <h2 className="text-xl font-semibold">IDADE DAS AVES</h2>
                        <p className="mt-2 text-3xl font-bold">--</p>
                    </div>
                    
                    {/* Lot Number */}
                    <div className="bg-[#FF9349] w-full h-30 text-white p-6 shadow-lg rounded-lg text-center lg:col-start-4">
                        <h2 className="text-xl font-semibold">N° do lote</h2>
                        <p className="mt-2 text-3xl font-bold">--</p>
                    </div>

                    {/* Lot Start - full width on mobile, spans 2 cols on lg+ */}
                    <div className="bg-[#FF9349] w-full h-30 text-white p-6 shadow-lg rounded-lg text-center lg:col-start-3 lg:col-span-2">
                        <h2 className="text-xl font-semibold">Início do lote</h2>
                        <p className="mt-2 text-3xl font-bold">xx/xx/xxxx</p>
                    </div>
                    
                    {/* Category - full width on mobile, spans 2 cols on lg+ */}
                    <div className="bg-[#FF9349] w-full h-30 text-white p-6 shadow-lg rounded-lg text-center lg:col-start-3 lg:col-span-2">
                        <h2 className="text-xl font-semibold">CATEGORIA</h2>
                        <p className="mt-2 text-3xl font-bold">Frango de corte</p>
                    </div>
                </div>
            </div>

            {/* Reports Button */}
            <div className="mb-10 mt-6">
                <div className="flex justify-center w-full md:w-72 mx-auto">
                    <Link className="text-2xl shadow-md shadow-black/50" to="/Relatório">
                        <Thirdbutton
                            text="Gerar relatórios"
                            type="button"
                        />
                    </Link>
                </div>
            </div>
        </div>
    );
}
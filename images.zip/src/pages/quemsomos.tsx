"use client";
import MenuQuem from "@/components/menuquem";
import { Link } from "react-router-dom";
import LogoIni from "@/assets/Logo.png";
import Thirdbutton from "@/components/buttons/thirdbutton";
import Footer from "@/components/footer";

export default function quemsomos() {
    return (
        <div className="w-full h-screen bg-[#FFF7E3] flex flex-col">
            
            {/* Div Pai contendo Header, Body e Footer */}
            <div className="flex flex-col h-full">

                {/* Header */}
                {/* O Header é o topo da página, geralmente com informações de navegação ou login */}
                <div>
                    <MenuQuem />
                </div>
                
                {/* Body */}
                {/* O Body é o conteúdo principal da página, onde a maior parte das informações interativas e de layout são exibidas */}
                <div className="bg-[url('/images/processo.jpg')] shadow-[inset_0_-4px_0_0_#222222] flex flex-col lg:flex-row justify-center items-center lg:items-start  w-full flex-grow overflow-y-auto">
                    
                </div>

                {/* Footer */}
                {/* O Footer é a parte inferior da página, geralmente com links de navegação secundários e informações complementares */}
                <div>
                    <Footer />
                </div>
            </div>
        </div>
    );
}

"use client";
import Menudash from "@/components/menudash";
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import { getDatabase, ref, onValue } from "firebase/database";
import app from "@/services/firebase";
import Menucalcu from "@/components/menucalcu";
import Temp from "@/assets/grafiT.png";
import Umi from "@/assets/grafiU.png";
import Lu from "@/assets/grafiL.png";

export default function calculos() {
    return (
        <div className="w-full min-h-screen bg-[#FFF7E3] flex flex-col">
            {/* Header */}
            <div>
                <Menucalcu/>
            </div>

            {/* Dashboard Layout */}
            <div className="w-full lg:w-350 lg:mt-10 lg:ml-65 p-4 lg:p-0">
                {/* Main Content - Single column on mobile, original layout on lg+ */}
                <div className="flex flex-col lg:flex-col gap-5">
                    {/* Top Row - Stacked on mobile, side-by-side on lg */}
                    <div className="flex flex-col lg:flex-row gap-5 lg:gap-10">
                        {/* Left Cards - Mortalidade and Ovos */}
                        <div className="flex flex-col gap-5 lg:gap-10 w-full lg:w-auto">
                            <div className="bg-[#FF0000] w-full lg:w-70 h-30 text-white p-6 shadow-lg rounded-lg text-center">
                                <h2 className="text-xl font-semibold">Mortalidade</h2>
                                <p className="mt-2 text-xl font-bold">--%</p>
                            </div>
                            <div className="bg-[#FC6701] w-full lg:w-70 h-30 text-white p-6 shadow-lg rounded-lg text-center">
                                <h2 className="text-xl font-semibold">Número de ovos coletados no dia</h2>
                                <p className="mt-2 text-xl font-bold">N°--</p>
                            </div>
                        </div>

                        {/* Images - Centered on both mobile and desktop */}
                        <div className="flex flex-col items-center justify-center gap-5 mx-auto w-full lg:w-auto">
                            <div className="scale-100 w-full lg:w-auto flex justify-center">
                                <img src={Temp.src} alt="Temperature" className="max-w-full" />
                            </div>
                            <div className="flex flex-col lg:flex-row justify-center gap-4 w-full">
                                <img src={Umi.src} alt="Humidity" className="max-w-full lg:scale-90" />
                                <img src={Lu.src} alt="Light" className="max-w-full lg:scale-90" />
                            </div>
                        </div>

                        {/* Right Cards - Lote and Viabilidade */}
                        <div className="flex flex-col gap-5 lg:gap-10 w-full lg:w-auto lg:mr-10">
                            <div className="bg-[#FC6701] w-full lg:w-70 h-30 text-white p-6 shadow-lg rounded-lg text-center">
                                <h2 className="text-xl font-semibold">Número de lote</h2>
                                <p className="mt-2 text-3xl font-bold">N°--</p>
                            </div>
                            <div className="bg-[#2554FC] w-full lg:w-70 h-30 text-white p-6 shadow-lg rounded-lg text-center">
                                <h2 className="text-xl font-semibold">Viabilidade</h2>
                                <p className="mt-2 text-3xl font-bold">--%</p>
                            </div>
                        </div>
                    </div>

                    {/* Bottom Row - Always centered but stacked on mobile */}
                    <div className="flex flex-col lg:flex-row items-center justify-center gap-5 lg:gap-20">
                        <div className="bg-[#FC6701] w-full lg:w-70 h-30 text-white p-6 shadow-lg rounded-lg text-center">
                            <h2 className="text-xl font-semibold">Índice de produção</h2>
                            <p className="mt-2 text-3xl font-bold">--%</p>
                        </div>
                        <div className="bg-[#FC6701] w-full lg:w-70 h-30 text-white p-6 shadow-lg rounded-lg text-center">
                            <h2 className="text-xl font-semibold">Fator de produção</h2>
                            <p className="mt-2 text-3xl font-bold">--%</p>
                        </div>
                        <div className="bg-[#FC6701] w-full lg:w-70 h-30 text-white p-6 shadow-lg rounded-lg text-center">
                            <h2 className="text-xl font-semibold">Conversão alimentar</h2>
                            <p className="mt-2 text-3xl font-bold">--%</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
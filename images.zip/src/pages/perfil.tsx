"use client";
import Menuperfil from "@/components/menuperfil";
import { Link } from "react-router-dom";
import LogoIni from "@/assets/Logo.png";
import Footer from "@/components/footer";
import { useState } from "react";
import { FiMenu, FiX, FiHome, FiSettings, FiUser } from "react-icons/fi";
import Quartobutton from "@/components/buttons/quartobutton";

export default function perfil() {
    const [sidebarOpen, setSidebarOpen] = useState(false);

    return (
        <div className="w-full min-h-screen bg-[#FFF7E3] flex flex-col overflow-hidden">
            {/* Header */}
            <div>
                <Menuperfil />
            </div>

            {/* Dashboard Layout */}
            <div className="flex flex-grow">
            <div className="bg-[#FFFFFF] w-75 h-50 text-white p-6 shadow-lg shadow-black/50 rounded-lg text-center">
                                    <h2 className="text-xl mb-15 font-semibold text-[#23306A]">Sensores</h2>
                                    <Link to="/">
                                    <Quartobutton
                                        text="Gerar relatórios"
                                        type="button"
                                    />
                                    </Link>
                                    
                                </div>
            </div>
        </div>
    );
}

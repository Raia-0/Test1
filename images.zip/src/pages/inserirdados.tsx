"use client";
import Menudash from "@/components/menudash";
import { Link } from "react-router-dom";
import LogoIni from "@/assets/Logo.png";
import Footer from "@/components/footer";
import { useState } from "react";
import { FiMenu, FiX, FiHome, FiSettings, FiUser, FiAlertCircle } from "react-icons/fi";
import Thirdbutton from "@/components/buttons/thirdbutton";
import Quartobutton from "@/components/buttons/quartobutton";
import Menuinserdados from "@/components/menuinserdados";

export default function inserirdados() {
    const [sidebarOpen, setSidebarOpen] = useState(false);

    // Tooltip content for each card
    const tooltips = {
        mortalidade: "Fórmula: (N° de aves mortas / N° inicial de aves) × 100",
        viabilidade: "Fórmula: ((N° inicial - N° mortas) / N° inicial) × 100",
        ovos: "Fórmula: Soma diária de ovos coletados",
        conversao: "Fórmula: Consumo total de ração / Peso total de ovos",
        fator: "Fórmula: (N° de ovos × Peso médio) / N° de aves",
        peso: "Fórmula: Peso total / N° de aves",
        indice: "Fórmula: (Peso médio × Viabilidade) / Idade × Fator",
        ganho: "Fórmula: (Peso final - Peso inicial) / Período",
        lote: "Datas de início e término do ciclo produtivo"
    };

    return (
        <div className="w-full min-h-screen bg-[#FFF7E3] flex flex-col">
            {/* Header - Agora posicionado corretamente */}
            <header className="sticky top-0 z-50 w-full">
                <Menuinserdados />
            </header>

            {/* Main Content */}
            <main className="flex-1 flex flex-col overflow-hidden">
                {/* Dashboard Layout - TODAS AS DIVS PRESERVADAS */}
                <div className="w-auto bg-[#FFF7E3] px-4 lg:ml-80 lg:mr-60 mb-4 overflow-y-auto flex-1">
                    <div className="mt-3 grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-20 justify-center">
                        {/* Mortalidade */}
                        <div className="relative bg-[#FFFFFF] w-full lg:w-75 h-50 text-white p-6 shadow-lg shadow-black/50 rounded-lg text-center">
                            <div className="group relative">
                                <FiAlertCircle className="absolute top-2 right-2 text-yellow-500 text-xl cursor-pointer" />
                                <div className="absolute hidden group-hover:block right-0 top-8 w-64 p-2 bg-orange-500 text-white text-sm rounded-lg z-10">
                                    {tooltips.mortalidade}
                                </div>
                            </div>
                            <h2 className="text-xl mb-15 font-semibold text-[#23306A]">Mortalidade</h2>
                            <Quartobutton text="Inserir dados" type="button" />
                        </div>

                        {/* Viabilidade */}
                        <div className="relative bg-[#FFFFFF] w-full lg:w-75 h-50 text-white p-6 shadow-lg shadow-black/50 rounded-lg text-center">
                            <div className="group relative">
                                <FiAlertCircle className="absolute top-2 right-2 text-yellow-500 text-xl cursor-pointer" />
                                <div className="absolute hidden group-hover:block right-0 top-8 w-64 p-2 bg-orange-500 text-white text-sm rounded-lg z-10">
                                    {tooltips.viabilidade}
                                </div>
                            </div>
                            <h2 className="text-xl mb-15 font-semibold text-[#23306A]">Viabilidade</h2>
                            <Quartobutton text="Inserir dados" type="button" />
                        </div>

                        {/* Ovos coletados */}
                        <div className="relative bg-[#FFFFFF] w-full lg:w-75 h-50 text-white p-6 shadow-lg shadow-black/50 rounded-lg text-center">
                            <div className="group relative">
                                <FiAlertCircle className="absolute top-2 right-2 text-yellow-500 text-xl cursor-pointer" />
                                <div className="absolute hidden group-hover:block right-0 top-8 w-64 p-2 bg-orange-500 text-white text-sm rounded-lg z-10">
                                    {tooltips.ovos}
                                </div>
                            </div>
                            <h2 className="text-xl mb-15 font-semibold text-[#23306A]">Ovo coletados(dia)</h2>
                            <Quartobutton text="Inserir dados" type="button" />
                        </div>

                        {/* Conversão alimentar */}
                        <div className="relative bg-[#FFFFFF] w-full lg:w-75 h-50 text-white p-6 shadow-lg shadow-black/50 rounded-lg text-center">
                            <div className="group relative">
                                <FiAlertCircle className="absolute top-2 right-2 text-yellow-500 text-xl cursor-pointer" />
                                <div className="absolute hidden group-hover:block right-0 top-8 w-64 p-2 bg-orange-500 text-white text-sm rounded-lg z-10">
                                    {tooltips.conversao}
                                </div>
                            </div>
                            <h2 className="text-xl mb-15 font-semibold text-[#23306A]">Conversão alimentar</h2>
                            <Quartobutton text="Inserir dados" type="button" />
                        </div>

                        {/* Fator de produção */}
                        <div className="relative bg-[#FFFFFF] w-full lg:w-75 h-50 text-white p-6 shadow-lg shadow-black/50 rounded-lg text-center">
                            <div className="group relative">
                                <FiAlertCircle className="absolute top-2 right-2 text-yellow-500 text-xl cursor-pointer" />
                                <div className="absolute hidden group-hover:block right-0 top-8 w-64 p-2 bg-orange-500 text-white text-sm rounded-lg z-10">
                                    {tooltips.fator}
                                </div>
                            </div>
                            <h2 className="text-xl mb-15 font-semibold text-[#23306A]">Fator de produção</h2>
                            <Quartobutton text="Inserir dados" type="button" />
                        </div>

                        {/* Peso médio */}
                        <div className="relative bg-[#FFFFFF] w-full lg:w-75 h-50 text-white p-6 shadow-lg shadow-black/50 rounded-lg text-center">
                            <div className="group relative">
                                <FiAlertCircle className="absolute top-2 right-2 text-yellow-500 text-xl cursor-pointer" />
                                <div className="absolute hidden group-hover:block right-0 top-8 w-64 p-2 bg-orange-500 text-white text-sm rounded-lg z-10">
                                    {tooltips.peso}
                                </div>
                            </div>
                            <h2 className="text-xl mb-15 font-semibold text-[#23306A]">Peso médio</h2>
                            <Quartobutton text="Inserir dados" type="button" />
                        </div>

                        {/* Índice de eficiência */}
                        <div className="relative bg-[#FFFFFF] w-full lg:w-75 h-50 text-white p-6 shadow-lg shadow-black/50 rounded-lg text-center">
                            <div className="group relative">
                                <FiAlertCircle className="absolute top-2 right-2 text-yellow-500 text-xl cursor-pointer" />
                                <div className="absolute hidden group-hover:block right-0 top-8 w-64 p-2 bg-orange-500 text-white text-sm rounded-lg z-10">
                                    {tooltips.indice}
                                </div>
                            </div>
                            <h2 className="text-xl mb-15 font-semibold text-[#23306A]">Índice de eficiência produtiva</h2>
                            <Quartobutton text="Inserir dados" type="button" />
                        </div>

                        {/* Ganho médio */}
                        <div className="relative bg-[#FFFFFF] w-full lg:w-75 h-50 text-white p-6 shadow-lg shadow-black/50 rounded-lg text-center">
                            <div className="group relative">
                                <FiAlertCircle className="absolute top-2 right-2 text-yellow-500 text-xl cursor-pointer" />
                                <div className="absolute hidden group-hover:block right-0 top-8 w-64 p-2 bg-orange-500 text-white text-sm rounded-lg z-10">
                                    {tooltips.ganho}
                                </div>
                            </div>
                            <h2 className="text-xl mb-15 font-semibold text-[#23306A]">Ganho médio de peso</h2>
                            <Quartobutton text="Inserir dados" type="button" />
                        </div>

                        {/* Inicio e fim do lote */}
                        <div className="relative bg-[#FFFFFF] w-full lg:w-75 h-50 text-white p-6 shadow-lg shadow-black/50 rounded-lg text-center">
                            <div className="group relative">
                                <FiAlertCircle className="absolute top-2 right-2 text-yellow-500 text-xl cursor-pointer" />
                                <div className="absolute hidden group-hover:block right-0 top-8 w-64 p-2 bg-orange-500 text-white text-sm rounded-lg z-10">
                                    {tooltips.lote}
                                </div>
                            </div>
                            <h2 className="text-xl mb-15 font-semibold text-[#23306A]">Inicio e fim do lote</h2>
                            <Quartobutton text="Inserir dados" type="button" />
                        </div>
                    </div>
                </div>

                {/* Button Container - Fixed at bottom */}
                <div className="w-full py-4 bg-[#FFF7E3] sticky bottom-0 z-10">
                    <div className="flex justify-center">
                        <Link className="text-2xl" to="/padada">
                            <Quartobutton
                                text="Inserir todos os dados"
                                type="button"
                            />
                        </Link>
                    </div>
                </div>
            </main>
        </div>
    );
}